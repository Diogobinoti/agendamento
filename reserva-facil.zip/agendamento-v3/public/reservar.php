<?php
// public/reservar.php
require '../includes/auth.php';
exigirLogin();
require '../config/conexao.php';

$erro    = '';
$sucesso = '';
$espacoPreSelecionado = (int)($_GET['espaco'] ?? 0);

// Busca espaços ativos com preço (necessário para o JS calcular o total)
$stmtEspacos = $conn->prepare('SELECT id, nome, tipo, preco_hora FROM espacos WHERE ativo = 1 ORDER BY nome');
$stmtEspacos->execute();
$espacos = $stmtEspacos->get_result();
$stmtEspacos->close();

// Monta array para passar ao JS sem fazer segunda query
$espacosArr = [];
$espacos->data_seek(0);
while ($e = $espacos->fetch_assoc()) {
    $espacosArr[] = $e;
}

// --- Processa POST vindo do modal de confirmação ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioId = (int)$_SESSION['id'];
    $espacoId  = (int)($_POST['espaco_id'] ?? 0);
    $data      = $_POST['data']    ?? '';
    $inicio    = $_POST['inicio']  ?? '';  // formato: "08:00"
    $fim       = $_POST['fim']     ?? '';  // formato: "10:00"

    if (!$espacoId || !$data || !$inicio || !$fim) {
        $erro = 'Dados incompletos. Tente novamente.';
    } elseif ($data < date('Y-m-d')) {
        $erro = 'Não é possível reservar para datas passadas.';
    } elseif ($fim <= $inicio) {
        $erro = 'Horário inválido.';
    } else {
        // Confirma ausência de conflito no servidor (nunca confiar só no JS)
        $stmtConf = $conn->prepare(
            'SELECT id FROM reservas
             WHERE espaco_id    = ?
               AND data_reserva = ?
               AND status       = "ativa"
               AND hora_inicio  < ?
               AND hora_fim     > ?'
        );
        $inicioFull = $inicio . ':00';
        $fimFull    = $fim    . ':00';
        $stmtConf->bind_param('isss', $espacoId, $data, $fimFull, $inicioFull);
        $stmtConf->execute();
        $stmtConf->store_result();

        if ($stmtConf->num_rows > 0) {
            $erro = 'Conflito de horário detectado. O período já foi reservado.';
        } else {
            $stmtIns = $conn->prepare(
                'INSERT INTO reservas (usuario_id, espaco_id, data_reserva, hora_inicio, hora_fim)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $stmtIns->bind_param('iisss', $usuarioId, $espacoId, $data, $inicioFull, $fimFull);
            if ($stmtIns->execute()) {
                $sucesso = 'Reserva confirmada com sucesso!';
            } else {
                $erro = 'Erro ao salvar. Tente novamente.';
            }
            $stmtIns->close();
        }
        $stmtConf->close();
    }
}
?>
<?php include '../includes/header.php'; ?>

<main class="container">
    <div class="page-top">
        <h1>Nova Reserva</h1>
        <a href="minhas_reservas.php" class="btn btn-outline">Minhas reservas</a>
    </div>

    <?php if ($erro): ?>
        <div class="alert alert-erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>
    <?php if ($sucesso): ?>
        <div class="alert alert-ok"><?= htmlspecialchars($sucesso) ?></div>
    <?php endif; ?>

    <!-- Seleção de espaço e data -->
    <div class="card">
        <div class="reserva-selecao">
            <div>
                <label for="sel-espaco">Espaço</label>
                <select id="sel-espaco">
                    <option value="">-- Selecione um espaço --</option>
                    <?php foreach ($espacosArr as $e): ?>
                        <option value="<?= $e['id'] ?>"
                                data-preco="<?= $e['preco_hora'] ?>"
                                data-nome="<?= htmlspecialchars($e['nome']) ?>"
                                data-tipo="<?= htmlspecialchars($e['tipo']) ?>"
                                <?= $e['id'] === $espacoPreSelecionado ? 'selected' : '' ?>>
                            [<?= htmlspecialchars($e['tipo']) ?>] <?= htmlspecialchars($e['nome']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="sel-data">Data</label>
                <input type="date" id="sel-data" min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>">
            </div>
        </div>
    </div>

    <!-- Agenda — aparece após seleção -->
    <div id="agenda-wrap" style="margin-top:1.25rem"></div>

    <!-- Modal de confirmação (fora do flow, fica escondido) -->
    <div id="modal-wrap"></div>

    <!-- Formulário oculto — submetido pelo JS ao confirmar -->
    <form id="form-reserva" method="POST" style="display:none">
        <input type="hidden" name="espaco_id" id="f-espaco-id">
        <input type="hidden" name="data"      id="f-data">
        <input type="hidden" name="inicio"    id="f-inicio">
        <input type="hidden" name="fim"       id="f-fim">
    </form>
</main>

<style>
.reserva-selecao { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
@media (max-width: 520px) { .reserva-selecao { grid-template-columns: 1fr; } }

.agenda-card { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--border-radius-lg); overflow: hidden; }
.agenda-topo { display: grid; grid-template-columns: 64px 1fr; border-bottom: 0.5px solid var(--color-border-tertiary); padding: 10px 0; background: var(--color-background-secondary); }
.agenda-topo-hora { font-size: 12px; color: var(--color-text-tertiary); text-align: center; }
.agenda-topo-nome { font-size: 13px; font-weight: 500; color: var(--color-text-primary); padding-left: 12px; }

.agenda-body { max-height: 440px; overflow-y: auto; }
.slot-row { display: grid; grid-template-columns: 64px 1fr; border-bottom: 0.5px solid var(--color-border-tertiary); min-height: 50px; }
.slot-row:last-child { border-bottom: none; }
.slot-hora { font-size: 12px; color: var(--color-text-secondary); display: flex; align-items: center; justify-content: center; border-right: 0.5px solid var(--color-border-tertiary); }
.slot-bloco { margin: 6px 8px; border-radius: var(--border-radius-md); display: flex; align-items: center; padding: 0 12px; font-size: 13px; min-height: 38px; }
.slot-livre { background: var(--color-background-success); color: var(--color-text-success); border: 0.5px solid #c0dd97; cursor: pointer; }
.slot-livre:hover { opacity: 0.75; }
.slot-ocupado { background: var(--color-background-secondary); color: var(--color-text-tertiary); border: 0.5px solid var(--color-border-tertiary); cursor: not-allowed; }
.slot-inicio { background: var(--color-background-info); color: var(--color-text-info); border: 2px solid var(--color-border-info); font-weight: 500; cursor: pointer; }
.slot-range  { background: var(--color-background-info); color: var(--color-text-info); border: 0.5px solid var(--color-border-info); opacity: 0.6; cursor: pointer; }

.agenda-instrucao { font-size: 13px; color: var(--color-text-secondary); padding: 10px 12px; background: var(--color-background-secondary); border-radius: var(--border-radius-md); margin-bottom: 1rem; display: flex; align-items: center; gap: 8px; }
.agenda-legenda { display: flex; gap: 16px; margin-bottom: 1rem; flex-wrap: wrap; }
.leg { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--color-text-secondary); }
.leg-box { width: 14px; height: 14px; border-radius: 4px; }
.lb-livre { background: var(--color-background-success); border: 0.5px solid #c0dd97; }
.lb-ocup  { background: var(--color-background-secondary); border: 0.5px solid var(--color-border-tertiary); }
.lb-sel   { background: var(--color-background-info); border: 0.5px solid var(--color-border-info); }

.agenda-vazio { padding: 3rem; text-align: center; color: var(--color-text-secondary); font-size: 14px; }

/* Modal */
.modal-bg { background: rgba(0,0,0,0.45); border-radius: var(--border-radius-lg); display: flex; align-items: center; justify-content: center; min-height: 380px; margin-top: 1rem; }
.modal-box { background: var(--color-background-primary); border-radius: var(--border-radius-lg); border: 0.5px solid var(--color-border-tertiary); padding: 1.5rem; width: 100%; max-width: 420px; margin: 1rem; }
.modal-titulo { font-size: 16px; font-weight: 500; margin-bottom: 1.25rem; color: var(--color-text-primary); }
.modal-linha { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 0.5px solid var(--color-border-tertiary); font-size: 14px; }
.modal-linha:last-of-type { border-bottom: none; }
.modal-lbl { color: var(--color-text-secondary); }
.modal-val { font-weight: 500; color: var(--color-text-primary); }
.modal-total { margin-top: 1rem; padding: 10px 14px; background: var(--color-background-secondary); border-radius: var(--border-radius-md); display: flex; justify-content: space-between; align-items: center; }
.modal-total-lbl { font-size: 13px; color: var(--color-text-secondary); }
.modal-total-val { font-size: 20px; font-weight: 500; color: var(--color-text-primary); }
.modal-acoes { display: flex; gap: 10px; margin-top: 1.25rem; }
.modal-acoes button { flex: 1; padding: 10px; border-radius: var(--border-radius-md); font-size: 14px; cursor: pointer; border: none; }
.btn-confirmar-modal { background: var(--color-background-success); color: var(--color-text-success); border: 0.5px solid #639922 !important; font-weight: 500; }
.btn-cancelar-modal  { background: var(--color-background-secondary); color: var(--color-text-secondary); border: 0.5px solid var(--color-border-secondary) !important; }
.btn-confirmar-modal:hover { opacity: 0.85; }
.btn-cancelar-modal:hover  { background: var(--color-background-tertiary); }
</style>

<script>
const HORAS = Array.from({length: 16}, (_, i) => i + 6); // 06h às 21h
const pad = n => String(n).padStart(2, '0');

let estadoSel  = null;
let reservasDia = [];
let espacoInfo = { id: null, nome: '', preco: 0 };

const selEspaco  = document.getElementById('sel-espaco');
const selData    = document.getElementById('sel-data');
const agendaWrap = document.getElementById('agenda-wrap');
const modalWrap  = document.getElementById('modal-wrap');

function formatarDataBR(iso) {
    const [y, m, d] = iso.split('-');
    return `${d}/${m}/${y}`;
}

function isOcupado(h) {
    return reservasDia.some(r => {
        const ini = parseInt(r.hora_inicio.substring(0, 2));
        const fim = parseInt(r.hora_fim.substring(0, 2));
        return h >= ini && h < fim;
    });
}

function temConflito(ini, fim) {
    return reservasDia.some(r => {
        const rIni = parseInt(r.hora_inicio.substring(0, 2));
        const rFim = parseInt(r.hora_fim.substring(0, 2));
        return rIni < fim && rFim > ini;
    });
}

async function carregarAgenda() {
    const eId   = selEspaco.value;
    const data  = selData.value;
    const opt   = selEspaco.options[selEspaco.selectedIndex];

    estadoSel = null;
    modalWrap.innerHTML = '';

    if (!eId || !data) {
        agendaWrap.innerHTML = `
            <div class="agenda-vazio">
                Selecione um espaço e uma data para ver os horários disponíveis.
            </div>`;
        return;
    }

    espacoInfo = {
        id:    eId,
        nome:  opt.dataset.nome,
        tipo:  opt.dataset.tipo,
        preco: parseFloat(opt.dataset.preco)
    };

    agendaWrap.innerHTML = `<div class="agenda-vazio">Carregando horários...</div>`;

    try {
        const res  = await fetch(`disponibilidade.php?espaco=${eId}&data=${data}`);
        const json = await res.json();
        reservasDia = json.reservas || [];
    } catch(e) {
        agendaWrap.innerHTML = `<div class="agenda-vazio">Erro ao carregar horários. Tente novamente.</div>`;
        return;
    }

    const livres   = HORAS.filter(h => !isOcupado(h)).length;
    const ocupados = HORAS.length - livres;

    agendaWrap.innerHTML = `
        <div class="agenda-instrucao" id="instrucao">
            Clique num horário livre para marcar o <strong>início</strong>. Depois clique no horário de <strong>fim</strong>.
        </div>
        <div class="agenda-legenda">
            <div class="leg"><div class="leg-box lb-livre"></div> Disponível (${livres}h)</div>
            <div class="leg"><div class="leg-box lb-ocup"></div> Ocupado (${ocupados}h)</div>
            <div class="leg"><div class="leg-box lb-sel"></div> Selecionado</div>
        </div>
        <div class="agenda-card">
            <div class="agenda-topo">
                <div class="agenda-topo-hora">Hora</div>
                <div class="agenda-topo-nome">${espacoInfo.nome} &mdash; ${formatarDataBR(data)}</div>
            </div>
            <div class="agenda-body" id="agenda-body"></div>
        </div>`;

    const body = document.getElementById('agenda-body');
    HORAS.forEach(h => {
        const ocup = isOcupado(h);
        const row  = document.createElement('div');
        row.className = 'slot-row';

        const bloco = document.createElement('div');
        bloco.className = 'slot-bloco ' + (ocup ? 'slot-ocupado' : 'slot-livre');
        bloco.dataset.hora = h;
        bloco.innerHTML = ocup
            ? '<span>Ocupado</span>'
            : '<span>Disponível</span>';

        if (!ocup) bloco.addEventListener('click', () => clicarSlot(h));

        row.innerHTML = `<div class="slot-hora">${pad(h)}:00</div>`;
        row.appendChild(bloco);
        body.appendChild(row);
    });
}

function clicarSlot(h) {
    if (!estadoSel) {
        estadoSel = { inicio: h };
        atualizarVisual();
        document.getElementById('instrucao').innerHTML =
            `Início: <strong>${pad(h)}:00</strong>. Agora clique no horário de <strong>fim</strong> (inclusive).`;
        return;
    }

    // Clicou no mesmo bloco — deseleciona
    if (h === estadoSel.inicio) {
        estadoSel = null;
        atualizarVisual();
        document.getElementById('instrucao').innerHTML =
            'Clique num horário livre para marcar o <strong>início</strong>. Depois clique no horário de <strong>fim</strong>.';
        return;
    }

    // Clicou antes do início — redefine início
    if (h < estadoSel.inicio) {
        estadoSel = { inicio: h };
        atualizarVisual();
        document.getElementById('instrucao').innerHTML =
            `Novo início: <strong>${pad(h)}:00</strong>. Clique no horário de <strong>fim</strong>.`;
        return;
    }

    // h é o último bloco selecionado; o fim real é h+1
    const fim = h + 1;

    if (temConflito(estadoSel.inicio, fim)) {
        document.getElementById('instrucao').innerHTML =
            '<span style="color:var(--color-text-warning)">Há um horário ocupado dentro do intervalo. Escolha outro fim.</span>';
        return;
    }

    // Tudo ok — abre modal
    estadoSel.fim = fim;
    atualizarVisual();
    abrirModal();
}

function atualizarVisual() {
    document.querySelectorAll('.slot-bloco').forEach(el => {
        if (el.classList.contains('slot-ocupado')) return;
        const h = parseInt(el.dataset.hora);
        el.classList.remove('slot-inicio', 'slot-range', 'slot-livre');

        if (estadoSel && h === estadoSel.inicio) {
            el.classList.add('slot-inicio');
            el.innerHTML = `<span>Início: ${pad(h)}:00</span>`;
        } else if (estadoSel && estadoSel.fim && h > estadoSel.inicio && h < estadoSel.fim) {
            el.classList.add('slot-range');
            el.innerHTML = `<span>${pad(h)}:00</span>`;
        } else {
            el.classList.add('slot-livre');
            el.innerHTML = `<span>Disponível</span>`;
        }
    });
}

function abrirModal() {
    const { inicio, fim } = estadoSel;
    const horas  = fim - inicio;
    const total  = horas * espacoInfo.preco;
    const data   = selData.value;

    modalWrap.innerHTML = `
        <div class="modal-bg">
            <div class="modal-box">
                <div class="modal-titulo">Confirmar reserva</div>
                <div class="modal-linha">
                    <span class="modal-lbl">Espaço</span>
                    <span class="modal-val">${espacoInfo.nome}</span>
                </div>
                <div class="modal-linha">
                    <span class="modal-lbl">Data</span>
                    <span class="modal-val">${formatarDataBR(data)}</span>
                </div>
                <div class="modal-linha">
                    <span class="modal-lbl">Horário</span>
                    <span class="modal-val">${pad(inicio)}:00 &rarr; ${pad(fim)}:00</span>
                </div>
                <div class="modal-linha">
                    <span class="modal-lbl">Duração</span>
                    <span class="modal-val">${horas}h</span>
                </div>
                <div class="modal-total">
                    <span class="modal-total-lbl">Total estimado</span>
                    <span class="modal-total-val">R$ ${total.toLocaleString('pt-BR', {minimumFractionDigits:2})}</span>
                </div>
                <div class="modal-acoes">
                    <button class="btn-cancelar-modal" onclick="fecharModal()">Cancelar</button>
                    <button class="btn-confirmar-modal" onclick="confirmar()">Confirmar reserva</button>
                </div>
            </div>
        </div>`;
}

function fecharModal() {
    modalWrap.innerHTML = '';
    estadoSel = null;
    atualizarVisual();
    document.getElementById('instrucao').innerHTML =
        'Clique num horário livre para marcar o <strong>início</strong>. Depois clique no horário de <strong>fim</strong>.';
}

function confirmar() {
    const { inicio, fim } = estadoSel;
    document.getElementById('f-espaco-id').value = espacoInfo.id;
    document.getElementById('f-data').value      = selData.value;
    document.getElementById('f-inicio').value    = pad(inicio) + ':00';
    document.getElementById('f-fim').value       = pad(fim)    + ':00';
    document.getElementById('form-reserva').submit();
}

selEspaco.addEventListener('change', carregarAgenda);
selData.addEventListener('change',   carregarAgenda);

// Dispara na carga se um espaço já estiver pré-selecionado via GET
if (selEspaco.value) carregarAgenda();
</script>

<?php include '../includes/footer.php'; ?>
