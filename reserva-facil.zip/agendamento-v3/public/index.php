<?php
// public/index.php
session_start();

if (!empty($_SESSION['id'])) {
    header('Location: dashboard.php');
} else {
    header('Location: login.php');
}
exit;